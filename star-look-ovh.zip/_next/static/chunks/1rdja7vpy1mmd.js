(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,23244,e=>{"use strict";var t=e.i(43476);let r=`
#define TWO_PI 6.28318530718
#define PI 3.14159265358979323846
`,o=`
vec2 rotate(vec2 uv, float th) {
  return mat2(cos(th), sin(th), -sin(th), cos(th)) * uv;
}
`,i=`
  color += 1. / 256. * (fract(sin(dot(.014 * gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453123) - .5);
`,s=`
vec3 permute(vec3 x) { return mod(((x * 34.0) + 1.0) * x, 289.0); }
float snoise(vec2 v) {
  const vec4 C = vec4(0.211324865405187, 0.366025403784439,
    -0.577350269189626, 0.024390243902439);
  vec2 i = floor(v + dot(v, C.yy));
  vec2 x0 = v - i + dot(i, C.xx);
  vec2 i1;
  i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec4 x12 = x0.xyxy + C.xxzz;
  x12.xy -= i1;
  i = mod(i, 289.0);
  vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0))
    + i.x + vec3(0.0, i1.x, 1.0));
  vec3 m = max(0.5 - vec3(dot(x0, x0), dot(x12.xy, x12.xy),
      dot(x12.zw, x12.zw)), 0.0);
  m = m * m;
  m = m * m;
  vec3 x = 2.0 * fract(p * C.www) - 1.0;
  vec3 h = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.79284291400159 - 0.85373472095314 * (a0 * a0 + h * h);
  vec3 g;
  g.x = a0.x * x0.x + h.x * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}
`,a=`#version 300 es
precision mediump float;

uniform sampler2D u_image;

uniform vec2 u_resolution;
uniform float u_time;

uniform vec4 u_colorBack;
uniform vec4 u_colorTint;

uniform float u_softness;
uniform float u_repetition;
uniform float u_shiftRed;
uniform float u_shiftBlue;
uniform float u_distortion;
uniform float u_contour;
uniform float u_angle;

uniform float u_shape;
uniform bool u_isImage;

in vec2 v_objectUV;
in vec2 v_responsiveUV;
in vec2 v_responsiveBoxGivenSize;
in vec2 v_imageUV;

out vec4 fragColor;

${r}
${o}
${s}

float getColorChanges(float c1, float c2, float stripe_p, vec3 w, float blur, float bump, float tint) {

  float ch = mix(c2, c1, smoothstep(.0, 2. * blur, stripe_p));

  float border = w[0];
  ch = mix(ch, c2, smoothstep(border, border + 2. * blur, stripe_p));

  if (u_isImage == true) {
    bump = smoothstep(.2, .8, bump);
  }
  border = w[0] + .4 * (1. - bump) * w[1];
  ch = mix(ch, c1, smoothstep(border, border + 2. * blur, stripe_p));

  border = w[0] + .5 * (1. - bump) * w[1];
  ch = mix(ch, c2, smoothstep(border, border + 2. * blur, stripe_p));

  border = w[0] + w[1];
  ch = mix(ch, c1, smoothstep(border, border + 2. * blur, stripe_p));

  float gradient_t = (stripe_p - w[0] - w[1]) / w[2];
  float gradient = mix(c1, c2, smoothstep(0., 1., gradient_t));
  ch = mix(ch, gradient, smoothstep(border, border + .5 * blur, stripe_p));

  // Tint color is applied with color burn blending
  ch = mix(ch, 1. - min(1., (1. - ch) / max(tint, 0.0001)), u_colorTint.a);
  return ch;
}

float getImgFrame(vec2 uv, float th) {
  float frame = 1.;
  frame *= smoothstep(0., th, uv.y);
  frame *= 1.0 - smoothstep(1. - th, 1., uv.y);
  frame *= smoothstep(0., th, uv.x);
  frame *= 1.0 - smoothstep(1. - th, 1., uv.x);
  return frame;
}

float blurEdge3x3(sampler2D tex, vec2 uv, vec2 dudx, vec2 dudy, float radius, float centerSample) {
  vec2 texel = 1.0 / vec2(textureSize(tex, 0));
  vec2 r = radius * texel;

  float w1 = 1.0, w2 = 2.0, w4 = 4.0;
  float norm = 16.0;
  float sum = w4 * centerSample;

  sum += w2 * textureGrad(tex, uv + vec2(0.0, -r.y), dudx, dudy).r;
  sum += w2 * textureGrad(tex, uv + vec2(0.0, r.y), dudx, dudy).r;
  sum += w2 * textureGrad(tex, uv + vec2(-r.x, 0.0), dudx, dudy).r;
  sum += w2 * textureGrad(tex, uv + vec2(r.x, 0.0), dudx, dudy).r;

  sum += w1 * textureGrad(tex, uv + vec2(-r.x, -r.y), dudx, dudy).r;
  sum += w1 * textureGrad(tex, uv + vec2(r.x, -r.y), dudx, dudy).r;
  sum += w1 * textureGrad(tex, uv + vec2(-r.x, r.y), dudx, dudy).r;
  sum += w1 * textureGrad(tex, uv + vec2(r.x, r.y), dudx, dudy).r;

  return sum / norm;
}

float lst(float edge0, float edge1, float x) {
  return clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
}

void main() {

  const float firstFrameOffset = 2.8;
  float t = .3 * (u_time + firstFrameOffset);

  vec2 uv = v_imageUV;
  vec2 dudx = dFdx(v_imageUV);
  vec2 dudy = dFdy(v_imageUV);
  vec4 img = textureGrad(u_image, uv, dudx, dudy);

  if (u_isImage == false) {
    uv = v_objectUV + .5;
    uv.y = 1. - uv.y;
  }

  float cycleWidth = u_repetition;
  float edge = 0.;
  float contOffset = 1.;

  vec2 rotatedUV = uv - vec2(.5);
  float angle = (-u_angle + 70.) * PI / 180.;
  float cosA = cos(angle);
  float sinA = sin(angle);
  rotatedUV = vec2(
  rotatedUV.x * cosA - rotatedUV.y * sinA,
  rotatedUV.x * sinA + rotatedUV.y * cosA
  ) + vec2(.5);

  // u_contour is applied in 2 separate ranges:
  // - 0 to .4 sets the edge hardness, saturated above .4 (both branches below)
  // - .5 to 1 warps the stripes direction along the edges, inactive below .5 (see u_contour range 2)
  if (u_isImage == true) {
    float edgeRaw = img.r;
    edge = blurEdge3x3(u_image, uv, dudx, dudy, 6., edgeRaw);
    edge = pow(edge, 1.6);
    edge *= mix(0.0, 1.0, smoothstep(0.0, 0.4, u_contour));
  } else {
    if (u_shape < 1.) {
      // full-fill on canvas
      vec2 borderUV = v_responsiveUV + .5;
      float ratio = v_responsiveBoxGivenSize.x / v_responsiveBoxGivenSize.y;
      vec2 mask = min(borderUV, 1. - borderUV);
      vec2 pixel_thickness = min(250. / v_responsiveBoxGivenSize, vec2(.5));
      float maskX = smoothstep(0.0, pixel_thickness.x, mask.x);
      float maskY = smoothstep(0.0, pixel_thickness.y, mask.y);
      maskX = pow(maskX, .25);
      maskY = pow(maskY, .25);
      edge = clamp(1. - maskX * maskY, 0., 1.);

      uv = v_responsiveUV;
      if (ratio > 1.) {
        uv.y /= ratio;
      } else {
        uv.x *= ratio;
      }
      uv += .5;
      uv.y = 1. - uv.y;

      cycleWidth *= 2.;
      contOffset = 1.5;

    } else if (u_shape < 2.) {
      // circle
      vec2 shapeUV = uv - .5;
      shapeUV *= .67;
      edge = pow(clamp(3. * length(shapeUV), 0., 1.), 18.);
    } else if (u_shape < 3.) {
      // daisy
      vec2 shapeUV = uv - .5;
      shapeUV *= 1.68;

      float r = length(shapeUV) * 2.;
      float a = atan(shapeUV.y, shapeUV.x) + .2;
      r *= (1. + .05 * sin(3. * a + 2. * t));
      float f = abs(cos(a * 3.));
      edge = smoothstep(f, f + .7, r);
      edge *= edge;

      uv *= .8;
      cycleWidth *= 1.6;

    } else if (u_shape < 4.) {
      // diamond
      vec2 shapeUV = uv - .5;
      shapeUV = rotate(shapeUV, .25 * PI);
      shapeUV *= 1.42;
      shapeUV += .5;
      vec2 mask = min(shapeUV, 1. - shapeUV);
      vec2 pixel_thickness = vec2(.15);
      float maskX = smoothstep(0.0, pixel_thickness.x, mask.x);
      float maskY = smoothstep(0.0, pixel_thickness.y, mask.y);
      maskX = pow(maskX, .25);
      maskY = pow(maskY, .25);
      edge = clamp(1. - maskX * maskY, 0., 1.);
    } else if (u_shape < 5.) {
      // metaballs
      vec2 shapeUV = uv - .5;
      shapeUV *= 1.3;
      edge = 0.;
      for (int i = 0; i < 5; i++) {
        float fi = float(i);
        float speed = 1.5 + 2./3. * sin(fi * 12.345);
        float angle = -fi * 1.5;
        vec2 dir1 = vec2(cos(angle), sin(angle));
        vec2 dir2 = vec2(cos(angle + 1.57), sin(angle + 1.));
        vec2 traj = .4 * (dir1 * sin(t * speed + fi * 1.23) + dir2 * cos(t * (speed * 0.7) + fi * 2.17));
        float d = length(shapeUV + traj);
        edge += pow(1.0 - clamp(d, 0.0, 1.0), 4.0);
      }
      edge = 1. - smoothstep(.65, .9, edge);
      edge = pow(edge, 4.);
    }

    edge = mix(smoothstep(.9 - 2. * fwidth(edge), .9, edge), edge, smoothstep(0.0, 0.4, u_contour));

  }

  float opacity = 0.;
  if (u_isImage == true) {
    opacity = img.g;
    float frame = getImgFrame(v_imageUV, 0.);
    opacity *= frame;
  } else {
    opacity = 1. - smoothstep(.9 - 2. * fwidth(edge), .9, edge);
    if (u_shape < 2.) {
      edge = 1.2 * edge;
    } else if (u_shape < 5.) {
      edge = 1.8 * pow(edge, 1.5);
    }
  }

  float diagBLtoTR = rotatedUV.x - rotatedUV.y;
  float diagTLtoBR = rotatedUV.x + rotatedUV.y;

  vec3 color = vec3(0.);
  vec3 color1 = vec3(.98, 0.98, 1.);
  vec3 color2 = vec3(.1, .1, .1 + .1 * smoothstep(.7, 1.3, diagTLtoBR));

  vec2 grad_uv = uv - .5;

  float dist = length(grad_uv + vec2(0., .2 * diagBLtoTR));
  grad_uv = rotate(grad_uv, (.25 - .2 * diagBLtoTR) * PI);
  float direction = grad_uv.x;

  float bump = pow(1.8 * dist, 1.2);
  bump = 1. - bump;
  bump *= pow(uv.y, .3);


  float thin_strip_1_ratio = .12 / cycleWidth * (1. - .4 * bump);
  float thin_strip_2_ratio = .07 / cycleWidth * (1. + .4 * bump);
  float wide_strip_ratio = (1. - thin_strip_1_ratio - thin_strip_2_ratio);

  float thin_strip_1_width = cycleWidth * thin_strip_1_ratio;
  float thin_strip_2_width = cycleWidth * thin_strip_2_ratio;

  float noise = snoise(uv - t);

  edge += (1. - edge) * u_distortion * noise;

  direction += diagBLtoTR;
  float contour = 0.;
  direction -= 2. * noise * diagBLtoTR * (smoothstep(0., 1., edge) * (1.0 - smoothstep(0., 1., edge)));
  // u_contour range 2
  direction *= mix(1., 1. - edge, smoothstep(.5, 1., u_contour));
  direction -= 1.7 * edge * smoothstep(.5, 1., u_contour);
  direction += .2 * pow(u_contour, 4.) * (1.0 - smoothstep(0., 1., edge));

  bump *= clamp(pow(uv.y, .1), .3, 1.);
  direction *= (.1 + (1.1 - edge) * bump);

  direction *= (.4 + .6 * (1.0 - smoothstep(.5, 1., edge)));
  direction += .18 * (smoothstep(.1, .2, uv.y) * (1.0 - smoothstep(.2, .4, uv.y)));
  direction += .03 * (smoothstep(.1, .2, 1. - uv.y) * (1.0 - smoothstep(.2, .4, 1. - uv.y)));

  direction *= (.5 + .5 * pow(uv.y, 2.));
  direction *= cycleWidth;
  direction -= t;


  float colorDispersion = (1. - bump);
  colorDispersion = clamp(colorDispersion, 0., 1.);
  float dispersionRed = colorDispersion;
  dispersionRed += .03 * bump * noise;
  dispersionRed += 5. * (smoothstep(-.1, .2, uv.y) * (1.0 - smoothstep(.1, .5, uv.y))) * (smoothstep(.4, .6, bump) * (1.0 - smoothstep(.4, 1., bump)));
  dispersionRed -= diagBLtoTR;

  float dispersionBlue = colorDispersion;
  dispersionBlue *= 1.3;
  dispersionBlue += (smoothstep(0., .4, uv.y) * (1.0 - smoothstep(.1, .8, uv.y))) * (smoothstep(.4, .6, bump) * (1.0 - smoothstep(.4, .8, bump)));
  dispersionBlue -= .2 * edge;

  dispersionRed *= (u_shiftRed / 20.);
  dispersionBlue *= (u_shiftBlue / 20.);

  float blur = 0.;
  float rExtraBlur = 0.;
  float gExtraBlur = 0.;
  if (u_isImage == true) {
    float softness = 0.05 * u_softness;
    blur = softness + .5 * smoothstep(1., 10., u_repetition) * smoothstep(.0, 1., edge);
    float smallCanvasT = 1.0 - smoothstep(100., 500., min(u_resolution.x, u_resolution.y));
    blur += smallCanvasT * smoothstep(.0, 1., edge);
    rExtraBlur = softness * (0.05 + .1 * (u_shiftRed / 20.) * bump);
    gExtraBlur = softness * 0.05 / max(0.001, abs(1. - diagBLtoTR));
  } else {
    blur = u_softness / 15. + .3 * contour;
  }

  vec3 w = vec3(thin_strip_1_width, thin_strip_2_width, wide_strip_ratio);
  w[1] -= .02 * smoothstep(.0, 1., edge + bump);
  float stripe_r = fract(direction + dispersionRed);
  float r = getColorChanges(color1.r, color2.r, stripe_r, w, blur + fwidth(stripe_r) + rExtraBlur, bump, u_colorTint.r);
  float stripe_g = fract(direction);
  float g = getColorChanges(color1.g, color2.g, stripe_g, w, blur + fwidth(stripe_g) + gExtraBlur, bump, u_colorTint.g);
  float stripe_b = fract(direction - dispersionBlue);
  float b = getColorChanges(color1.b, color2.b, stripe_b, w, blur + fwidth(stripe_b), bump, u_colorTint.b);

  color = vec3(r, g, b);
  color *= opacity;

  vec3 bgColor = u_colorBack.rgb * u_colorBack.a;
  color = color + bgColor * (1. - opacity);
  opacity = opacity + u_colorBack.a * (1. - opacity);

  ${i}

  fragColor = vec4(color, opacity);
}
`,n=`#version 300 es
precision mediump float;

layout(location = 0) in vec4 a_position;

uniform vec2 u_resolution;
uniform float u_pixelRatio;
uniform float u_imageAspectRatio;
uniform float u_originX;
uniform float u_originY;
uniform float u_worldWidth;
uniform float u_worldHeight;
uniform float u_fit;
uniform float u_scale;
uniform float u_rotation;
uniform float u_offsetX;
uniform float u_offsetY;

out vec2 v_objectUV;
out vec2 v_objectBoxSize;
out vec2 v_responsiveUV;
out vec2 v_responsiveBoxGivenSize;
out vec2 v_patternUV;
out vec2 v_patternBoxSize;
out vec2 v_imageUV;

vec3 getBoxSize(float boxRatio, vec2 givenBoxSize) {
  vec2 box = vec2(0.);
  // fit = none
  box.x = boxRatio * min(givenBoxSize.x / boxRatio, givenBoxSize.y);
  float noFitBoxWidth = box.x;
  if (u_fit == 1.) { // fit = contain
    box.x = boxRatio * min(u_resolution.x / boxRatio, u_resolution.y);
  } else if (u_fit == 2.) { // fit = cover
    box.x = boxRatio * max(u_resolution.x / boxRatio, u_resolution.y);
  }
  box.y = box.x / boxRatio;
  return vec3(box, noFitBoxWidth);
}

void main() {
  gl_Position = a_position;

  vec2 uv = gl_Position.xy * .5;
  vec2 boxOrigin = vec2(.5 - u_originX, u_originY - .5);
  vec2 givenBoxSize = vec2(u_worldWidth, u_worldHeight);
  givenBoxSize = max(givenBoxSize, vec2(1.)) * u_pixelRatio;
  float r = u_rotation * 3.14159265358979323846 / 180.;
  mat2 graphicRotation = mat2(cos(r), sin(r), -sin(r), cos(r));
  vec2 graphicOffset = vec2(-u_offsetX, u_offsetY);


  // ===================================================

  float fixedRatio = 1.;
  vec2 fixedRatioBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );

  v_objectBoxSize = getBoxSize(fixedRatio, fixedRatioBoxGivenSize).xy;
  vec2 objectWorldScale = u_resolution.xy / v_objectBoxSize;

  v_objectUV = uv;
  v_objectUV *= objectWorldScale;
  v_objectUV += boxOrigin * (objectWorldScale - 1.);
  v_objectUV += graphicOffset;
  v_objectUV /= u_scale;
  v_objectUV = graphicRotation * v_objectUV;

  // ===================================================

  v_responsiveBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  float responsiveRatio = v_responsiveBoxGivenSize.x / v_responsiveBoxGivenSize.y;
  vec2 responsiveBoxSize = getBoxSize(responsiveRatio, v_responsiveBoxGivenSize).xy;
  vec2 responsiveBoxScale = u_resolution.xy / responsiveBoxSize;

  #ifdef ADD_HELPERS
  v_responsiveHelperBox = uv;
  v_responsiveHelperBox *= responsiveBoxScale;
  v_responsiveHelperBox += boxOrigin * (responsiveBoxScale - 1.);
  #endif

  v_responsiveUV = uv;
  v_responsiveUV *= responsiveBoxScale;
  v_responsiveUV += boxOrigin * (responsiveBoxScale - 1.);
  v_responsiveUV += graphicOffset;
  v_responsiveUV /= u_scale;
  v_responsiveUV.x *= responsiveRatio;
  v_responsiveUV = graphicRotation * v_responsiveUV;
  v_responsiveUV.x /= responsiveRatio;

  // ===================================================

  float patternBoxRatio = givenBoxSize.x / givenBoxSize.y;
  vec2 patternBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  patternBoxRatio = patternBoxGivenSize.x / patternBoxGivenSize.y;

  vec3 boxSizeData = getBoxSize(patternBoxRatio, patternBoxGivenSize);
  v_patternBoxSize = boxSizeData.xy;
  float patternBoxNoFitBoxWidth = boxSizeData.z;
  vec2 patternBoxScale = u_resolution.xy / v_patternBoxSize;

  v_patternUV = uv;
  v_patternUV += graphicOffset / patternBoxScale;
  v_patternUV += boxOrigin;
  v_patternUV -= boxOrigin / patternBoxScale;
  v_patternUV *= u_resolution.xy;
  v_patternUV /= u_pixelRatio;
  if (u_fit > 0.) {
    v_patternUV *= (patternBoxNoFitBoxWidth / v_patternBoxSize.x);
  }
  v_patternUV /= u_scale;
  v_patternUV = graphicRotation * v_patternUV;
  v_patternUV += boxOrigin / patternBoxScale;
  v_patternUV -= boxOrigin;
  // x100 is a default multiplier between vertex and fragmant shaders
  // we use it to avoid UV presision issues
  v_patternUV *= .01;

  // ===================================================

  vec2 imageBoxSize;
  if (u_fit == 1.) { // contain
    imageBoxSize.x = min(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else if (u_fit == 2.) { // cover
    imageBoxSize.x = max(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else {
    imageBoxSize.x = min(10.0, 10.0 / u_imageAspectRatio * u_imageAspectRatio);
  }
  imageBoxSize.y = imageBoxSize.x / u_imageAspectRatio;
  vec2 imageBoxScale = u_resolution.xy / imageBoxSize;

  v_imageUV = uv;
  v_imageUV *= imageBoxScale;
  v_imageUV += boxOrigin * (imageBoxScale - 1.);
  v_imageUV += graphicOffset;
  v_imageUV /= u_scale;
  v_imageUV.x *= u_imageAspectRatio;
  v_imageUV = graphicRotation * v_imageUV;
  v_imageUV.x /= u_imageAspectRatio;

  v_imageUV += .5;
  v_imageUV.y = 1. - v_imageUV.y;
}`,l=8294400;class c{parentElement;canvasElement;gl;program=null;uniformLocations={};fragmentShader;rafId=null;lastRenderTime=0;currentFrame=0;speed=0;currentSpeed=0;providedUniforms;mipmaps=[];hasBeenDisposed=!1;resolutionChanged=!0;textures=new Map;minPixelRatio;maxPixelCount;isSafari=(function(){let e=navigator.userAgent.toLowerCase();return e.includes("safari")&&!e.includes("chrome")&&!e.includes("android")})();uniformCache={};textureUnitMap=new Map;ownerDocument;constructor(e,t,r,o,i=0,s=0,a=2,n=l,c=[]){if(e?.nodeType===1)this.parentElement=e;else throw Error("Paper Shaders: parent element must be an HTMLElement");if(this.ownerDocument=e.ownerDocument,!this.ownerDocument.querySelector("style[data-paper-shader]")){let e=this.ownerDocument.createElement("style");e.innerHTML=u,e.setAttribute("data-paper-shader",""),this.ownerDocument.head.prepend(e)}let d=this.ownerDocument.createElement("canvas");this.canvasElement=d,this.parentElement.prepend(d),this.fragmentShader=t,this.providedUniforms=r,this.mipmaps=c,this.currentFrame=s,this.minPixelRatio=a,this.maxPixelCount=n;let h=d.getContext("webgl2",{antialias:!1,depth:!1,stencil:!1,...o});if(!h)throw Error("Paper Shaders: WebGL is not supported in this browser");this.gl=h,this.initProgram(),this.setupPositionAttribute(),this.setupUniforms(),this.setUniformValues(this.providedUniforms),this.setupResizeObserver(),visualViewport?.addEventListener("resize",this.handleVisualViewportChange),this.setupIntersectionObserver(),this.setSpeed(i),this.parentElement.setAttribute("data-paper-shader",""),this.parentElement.paperShaderMount=this,this.ownerDocument.addEventListener("visibilitychange",this.handleDocumentVisibilityChange)}initProgram=()=>{let e=function(e,t,r){let o=e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT),i=o?o.precision:null;i&&i<23&&(t=t.replace(/precision\s+(lowp|mediump)\s+float;/g,"precision highp float;"),r=r.replace(/precision\s+(lowp|mediump)\s+float/g,"precision highp float").replace(/\b(uniform|varying|attribute)\s+(lowp|mediump)\s+(\w+)/g,"$1 highp $3"));let s=d(e,e.VERTEX_SHADER,t),a=d(e,e.FRAGMENT_SHADER,r);if(!s||!a)return null;let n=e.createProgram();return n?(e.attachShader(n,s),e.attachShader(n,a),e.linkProgram(n),e.getProgramParameter(n,e.LINK_STATUS))?(e.detachShader(n,s),e.detachShader(n,a),e.deleteShader(s),e.deleteShader(a),n):(console.error("Unable to initialize the shader program: "+e.getProgramInfoLog(n)),e.deleteProgram(n),e.deleteShader(s),e.deleteShader(a),null):null}(this.gl,n,this.fragmentShader);e&&(this.program=e,this.gl.useProgram(e))};setupPositionAttribute=()=>{let e=this.gl.getAttribLocation(this.program,"a_position"),t=this.gl.createBuffer();this.gl.bindBuffer(this.gl.ARRAY_BUFFER,t),this.gl.bufferData(this.gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),this.gl.STATIC_DRAW),this.gl.enableVertexAttribArray(e),this.gl.vertexAttribPointer(e,2,this.gl.FLOAT,!1,0,0)};setupUniforms=()=>{let e={u_time:this.gl.getUniformLocation(this.program,"u_time"),u_pixelRatio:this.gl.getUniformLocation(this.program,"u_pixelRatio"),u_resolution:this.gl.getUniformLocation(this.program,"u_resolution")};Object.entries(this.providedUniforms).forEach(([t,r])=>{if(e[t]=this.gl.getUniformLocation(this.program,t),r instanceof HTMLImageElement){let r=`${t}AspectRatio`;e[r]=this.gl.getUniformLocation(this.program,r)}}),this.uniformLocations=e};renderScale=1;parentWidth=0;parentHeight=0;parentDevicePixelWidth=0;parentDevicePixelHeight=0;devicePixelsSupported=!1;intersectionObserver=null;isInViewport=!0;resizeObserver=null;setupResizeObserver=()=>{this.resizeObserver=new ResizeObserver(([e])=>{if(e?.borderBoxSize[0]){let t=e.devicePixelContentBoxSize?.[0];void 0!==t&&(this.devicePixelsSupported=!0,this.parentDevicePixelWidth=t.inlineSize,this.parentDevicePixelHeight=t.blockSize),this.parentWidth=e.borderBoxSize[0].inlineSize,this.parentHeight=e.borderBoxSize[0].blockSize}this.handleResize()}),this.resizeObserver.observe(this.parentElement)};setupIntersectionObserver=()=>{let e=this.ownerDocument.defaultView;e?.IntersectionObserver&&(this.intersectionObserver=new e.IntersectionObserver(([e])=>{this.isInViewport=e?.isIntersecting??!0,this.updateCurrentSpeed()}),this.intersectionObserver.observe(this.parentElement))};handleVisualViewportChange=()=>{this.resizeObserver?.disconnect(),this.setupResizeObserver()};handleResize=()=>{let e=0,t=0,r=Math.max(1,window.devicePixelRatio),o=visualViewport?.scale??1;if(this.devicePixelsSupported){let i=Math.max(1,this.minPixelRatio/r);e=this.parentDevicePixelWidth*i*o,t=this.parentDevicePixelHeight*i*o}else{var i;let s,a,n=Math.max(r,this.minPixelRatio)*o;this.isSafari&&(n*=Math.max(1,(i=this.ownerDocument,(a=Math.round(100*(s=outerWidth/((visualViewport?.scale??1)*(visualViewport?.width??window.innerWidth)+(window.innerWidth-i.documentElement.clientWidth)))))%5==0?a/100:33===a?1/3:67===a?2/3:133===a?4/3:s))),e=Math.round(this.parentWidth)*n,t=Math.round(this.parentHeight)*n}let s=Math.min(1,Math.sqrt(this.maxPixelCount)/Math.sqrt(e*t)),a=Math.round(e*s),n=Math.round(t*s),l=a/Math.round(this.parentWidth);(this.canvasElement.width!==a||this.canvasElement.height!==n||this.renderScale!==l)&&(this.renderScale=l,this.canvasElement.width=a,this.canvasElement.height=n,this.resolutionChanged=!0,this.gl.viewport(0,0,this.gl.canvas.width,this.gl.canvas.height),this.render(performance.now()))};render=e=>{if(this.hasBeenDisposed)return;if(null===this.program)return void console.warn("Tried to render before program or gl was initialized");let t=e-this.lastRenderTime;this.lastRenderTime=e,0!==this.currentSpeed&&(this.currentFrame+=t*this.currentSpeed),this.gl.clear(this.gl.COLOR_BUFFER_BIT),this.gl.uniform1f(this.uniformLocations.u_time,.001*this.currentFrame),this.resolutionChanged&&(this.gl.uniform2f(this.uniformLocations.u_resolution,this.gl.canvas.width,this.gl.canvas.height),this.gl.uniform1f(this.uniformLocations.u_pixelRatio,this.renderScale),this.resolutionChanged=!1),this.gl.drawArrays(this.gl.TRIANGLES,0,6),0!==this.currentSpeed?this.requestRender():this.rafId=null};requestRender=()=>{null!==this.rafId&&cancelAnimationFrame(this.rafId),this.rafId=requestAnimationFrame(this.render)};setTextureUniform=(e,t)=>{if(!t.complete||0===t.naturalWidth)throw Error(`Paper Shaders: image for uniform ${e} must be fully loaded`);let r=this.textures.get(e);r&&this.gl.deleteTexture(r),this.textureUnitMap.has(e)||this.textureUnitMap.set(e,this.textureUnitMap.size);let o=this.textureUnitMap.get(e);this.gl.activeTexture(this.gl.TEXTURE0+o);let i=this.gl.createTexture();this.gl.bindTexture(this.gl.TEXTURE_2D,i),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_WRAP_S,this.gl.CLAMP_TO_EDGE),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_WRAP_T,this.gl.CLAMP_TO_EDGE),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MIN_FILTER,this.gl.LINEAR),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MAG_FILTER,this.gl.LINEAR),this.gl.texImage2D(this.gl.TEXTURE_2D,0,this.gl.RGBA,this.gl.RGBA,this.gl.UNSIGNED_BYTE,t),this.mipmaps.includes(e)&&(this.gl.generateMipmap(this.gl.TEXTURE_2D),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MIN_FILTER,this.gl.LINEAR_MIPMAP_LINEAR));let s=this.gl.getError();if(s!==this.gl.NO_ERROR||null===i)return void console.error("Paper Shaders: WebGL error when uploading texture:",s);this.textures.set(e,i);let a=this.uniformLocations[e];if(a){this.gl.uniform1i(a,o);let r=`${e}AspectRatio`,i=this.uniformLocations[r];if(i){let e=t.naturalWidth/t.naturalHeight;this.gl.uniform1f(i,e)}}};areUniformValuesEqual=(e,t)=>e===t||!!(Array.isArray(e)&&Array.isArray(t))&&e.length===t.length&&e.every((e,r)=>this.areUniformValuesEqual(e,t[r]));setUniformValues=e=>{Object.entries(e).forEach(([e,t])=>{let r=t;if(t instanceof HTMLImageElement&&(r=`${t.src.slice(0,200)}|${t.naturalWidth}x${t.naturalHeight}`),this.areUniformValuesEqual(this.uniformCache[e],r))return;this.uniformCache[e]=r;let o=this.uniformLocations[e];if(!o)return void console.warn(`Uniform location for ${e} not found`);if(t instanceof HTMLImageElement)this.setTextureUniform(e,t);else if(Array.isArray(t)){let r=null,i=null;if(void 0!==t[0]&&Array.isArray(t[0])){let o=t[0].length;if(!t.every(e=>e.length===o))return void console.warn(`All child arrays must be the same length for ${e}`);r=t.flat(),i=o}else i=(r=t).length;switch(i){case 2:this.gl.uniform2fv(o,r);break;case 3:this.gl.uniform3fv(o,r);break;case 4:this.gl.uniform4fv(o,r);break;case 9:this.gl.uniformMatrix3fv(o,!1,r);break;case 16:this.gl.uniformMatrix4fv(o,!1,r);break;default:console.warn(`Unsupported uniform array length: ${i}`)}}else"number"==typeof t?this.gl.uniform1f(o,t):"boolean"==typeof t?this.gl.uniform1i(o,+!!t):console.warn(`Unsupported uniform type for ${e}: ${typeof t}`)})};getCurrentFrame=()=>this.currentFrame;setFrame=e=>{this.currentFrame=e,this.lastRenderTime=performance.now(),this.renderUnlessAnimating()};setSpeed=(e=1)=>{this.speed=e,this.updateCurrentSpeed()};updateCurrentSpeed=()=>{this.setCurrentSpeed(this.ownerDocument.hidden||!this.isInViewport?0:this.speed)};setCurrentSpeed=e=>{this.currentSpeed=e,null===this.rafId&&0!==e&&(this.lastRenderTime=performance.now(),this.rafId=requestAnimationFrame(this.render)),null!==this.rafId&&0===e&&(cancelAnimationFrame(this.rafId),this.rafId=null)};setMaxPixelCount=(e=l)=>{this.maxPixelCount=e,this.handleResize()};setMinPixelRatio=(e=2)=>{this.minPixelRatio=e,this.handleResize()};setUniforms=e=>{this.setUniformValues(e),this.providedUniforms={...this.providedUniforms,...e},this.renderUnlessAnimating()};renderUnlessAnimating=()=>{null===this.rafId&&this.render(performance.now())};handleDocumentVisibilityChange=()=>{this.updateCurrentSpeed()};dispose=()=>{this.hasBeenDisposed=!0,null!==this.rafId&&(cancelAnimationFrame(this.rafId),this.rafId=null),this.gl&&this.program&&(this.textures.forEach(e=>{this.gl.deleteTexture(e)}),this.textures.clear(),this.gl.deleteProgram(this.program),this.program=null,this.gl.bindBuffer(this.gl.ARRAY_BUFFER,null),this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER,null),this.gl.bindRenderbuffer(this.gl.RENDERBUFFER,null),this.gl.bindFramebuffer(this.gl.FRAMEBUFFER,null),this.gl.getError()),this.gl.getExtension("WEBGL_lose_context")?.loseContext(),this.resizeObserver&&(this.resizeObserver.disconnect(),this.resizeObserver=null),this.intersectionObserver&&(this.intersectionObserver.disconnect(),this.intersectionObserver=null),visualViewport?.removeEventListener("resize",this.handleVisualViewportChange),this.ownerDocument.removeEventListener("visibilitychange",this.handleDocumentVisibilityChange),this.uniformLocations={},this.canvasElement.remove(),delete this.parentElement.paperShaderMount}}function d(e,t,r){let o=e.createShader(t);return o?(e.shaderSource(o,r),e.compileShader(o),e.getShaderParameter(o,e.COMPILE_STATUS))?o:(console.error("An error occurred compiling the shaders: "+e.getShaderInfoLog(o)),e.deleteShader(o),null):null}let u=`@layer paper-shaders {
  :where([data-paper-shader]) {
    isolation: isolate;
    position: relative;

    & canvas {
      contain: strict;
      display: block;
      position: absolute;
      inset: 0;
      z-index: -1;
      width: 100%;
      height: 100%;
      border-radius: inherit;
      corner-shape: inherit;
    }
  }
}`;var h=e.i(56420);let p={name:"sparkles",size:24,node:[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],aliases:["stars"]};p.node;let m=(0,h.f)(p);var f=e.i(71645);function g({label:e="Get Started",onClick:r,viewMode:o="text",labelColor:i="#666666",ariaLabel:s}){let[n,l]=(0,f.useState)(!1),[d,u]=(0,f.useState)(!1),h=(0,f.useRef)(!1),[p,b]=(0,f.useState)([]),x=(0,f.useRef)(null),v=(0,f.useRef)(null),w=(0,f.useRef)(null),y=(0,f.useRef)(0),_=(0,f.useMemo)(()=>"icon"===o?{width:46,height:46,innerWidth:42,innerHeight:42,shaderWidth:46,shaderHeight:46}:{width:142,height:46,innerWidth:138,innerHeight:42,shaderWidth:142,shaderHeight:46},[o]);(0,f.useEffect)(()=>{let e="shader-canvas-style-exploded";if(!document.getElementById(e)){let t=document.createElement("style");t.id=e,t.textContent=`
        .shader-container-exploded canvas {
          width: 100% !important;
          height: 100% !important;
          display: block !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          border-radius: 100px !important;
        }
        @keyframes ripple-animation {
          0% {
            transform: translate(-50%, -50%) scale(0);
            opacity: 0.6;
          }
          100% {
            transform: translate(-50%, -50%) scale(4);
            opacity: 0;
          }
        }
      `,document.head.appendChild(t)}return(async()=>{try{x.current&&(v.current?.destroy&&v.current.destroy(),v.current=new c(x.current,a,{u_repetition:4,u_softness:.5,u_shiftRed:.3,u_shiftBlue:.3,u_distortion:0,u_contour:0,u_angle:45,u_scale:8,u_shape:1,u_offsetX:.1,u_offsetY:-.1},void 0,.6))}catch(e){console.error("[v0] Failed to load shader:",e)}})(),()=>{v.current?.destroy&&(v.current.destroy(),v.current=null)}},[]);let k=()=>{h.current=!0,l(!0),v.current?.setSpeed?.(1)},z=()=>{h.current=!1,l(!1),u(!1),v.current?.setSpeed?.(.6)};return(0,t.jsx)("div",{className:"relative inline-block",children:(0,t.jsx)("div",{style:{perspective:"1000px",perspectiveOrigin:"50% 50%"},children:(0,t.jsxs)("div",{style:{position:"relative",width:`${_.width}px`,height:`${_.height}px`,transformStyle:"preserve-3d",transition:"all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1), width 0.4s ease, height 0.4s ease",transform:"none"},children:[(0,t.jsxs)("div",{style:{position:"absolute",top:0,left:0,width:`${_.width}px`,height:`${_.height}px`,display:"flex",alignItems:"center",justifyContent:"center",gap:"6px",transformStyle:"preserve-3d",transition:"all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1), width 0.4s ease, height 0.4s ease, gap 0.4s ease",transform:"translateZ(20px)",zIndex:30,pointerEvents:"none"},children:["icon"===o&&(0,t.jsx)(m,{size:16,style:{color:i,filter:"drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.5))",transition:"all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)",transform:"scale(1)"}}),"text"===o&&(0,t.jsx)("span",{style:{fontSize:"14px",color:i,fontWeight:400,textShadow:"0px 1px 2px rgba(0, 0, 0, 0.5)",transition:"all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)",transform:"scale(1)",whiteSpace:"nowrap"},children:e})]}),(0,t.jsx)("div",{style:{position:"absolute",top:0,left:0,width:`${_.width}px`,height:`${_.height}px`,transformStyle:"preserve-3d",transition:"all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1), width 0.4s ease, height 0.4s ease",transform:`translateZ(10px) ${d?"translateY(1px) scale(0.98)":"translateY(0) scale(1)"}`,zIndex:20},children:(0,t.jsx)("div",{style:{width:`${_.innerWidth}px`,height:`${_.innerHeight}px`,margin:"2px",borderRadius:"100px",background:"linear-gradient(180deg, #202020 0%, #000000 100%)",boxShadow:d?"inset 0px 2px 4px rgba(0, 0, 0, 0.4), inset 0px 1px 2px rgba(0, 0, 0, 0.3)":"none",transition:"all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1), width 0.4s ease, height 0.4s ease, box-shadow 0.15s cubic-bezier(0.4, 0, 0.2, 1)"}})}),(0,t.jsx)("div",{style:{position:"absolute",top:0,left:0,width:`${_.width}px`,height:`${_.height}px`,transformStyle:"preserve-3d",transition:"all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1), width 0.4s ease, height 0.4s ease",transform:`translateZ(0px) ${d?"translateY(1px) scale(0.98)":"translateY(0) scale(1)"}`,zIndex:10},children:(0,t.jsx)("div",{style:{height:`${_.height}px`,width:`${_.width}px`,borderRadius:"100px",boxShadow:d?"0px 0px 0px 1px rgba(0, 0, 0, 0.5), 0px 1px 2px 0px rgba(0, 0, 0, 0.3)":n?"0px 0px 0px 1px rgba(0, 0, 0, 0.4), 0px 12px 6px 0px rgba(0, 0, 0, 0.05), 0px 8px 5px 0px rgba(0, 0, 0, 0.1), 0px 4px 4px 0px rgba(0, 0, 0, 0.15), 0px 1px 2px 0px rgba(0, 0, 0, 0.2)":"0px 0px 0px 1px rgba(0, 0, 0, 0.3), 0px 36px 14px 0px rgba(0, 0, 0, 0.02), 0px 20px 12px 0px rgba(0, 0, 0, 0.08), 0px 9px 9px 0px rgba(0, 0, 0, 0.12), 0px 2px 5px 0px rgba(0, 0, 0, 0.15)",transition:"all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1), width 0.4s ease, height 0.4s ease, box-shadow 0.15s cubic-bezier(0.4, 0, 0.2, 1)",background:"rgb(0 0 0 / 0)"},children:(0,t.jsx)("div",{ref:x,className:"shader-container-exploded",style:{borderRadius:"100px",overflow:"hidden",position:"relative",width:`${_.shaderWidth}px`,maxWidth:`${_.shaderWidth}px`,height:`${_.shaderHeight}px`,transition:"width 0.4s ease, height 0.4s ease"}})})}),(0,t.jsx)("button",{ref:w,type:"button",onClick:e=>{if(v.current?.setSpeed&&(v.current.setSpeed(2.4),setTimeout(()=>{h.current?v.current?.setSpeed?.(1):v.current?.setSpeed?.(.6)},300)),w.current){let t=w.current.getBoundingClientRect(),r=0===e.detail,o={x:r?t.width/2:e.clientX-t.left,y:r?t.height/2:e.clientY-t.top,id:y.current++};b(e=>[...e,o]),setTimeout(()=>{b(e=>e.filter(e=>e.id!==o.id))},600)}r?.()},onMouseEnter:k,onMouseLeave:z,onMouseDown:()=>u(!0),onMouseUp:()=>u(!1),onFocus:k,onBlur:z,onKeyDown:e=>{("Enter"===e.key||" "===e.key)&&u(!0)},onKeyUp:()=>u(!1),className:"focus-visible:ring-2 focus-visible:ring-[color:var(--liquid-metal-focus,rgba(255,255,255,0.85))] focus-visible:ring-offset-2 focus-visible:ring-offset-transparent",style:{position:"absolute",top:0,left:0,width:`${_.width}px`,height:`${_.height}px`,background:"transparent",border:"none",cursor:"pointer",outline:"none",zIndex:40,transformStyle:"preserve-3d",transform:"translateZ(25px)",transition:"all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1), width 0.4s ease, height 0.4s ease",overflow:"hidden",borderRadius:"100px"},"aria-label":s??e,children:p.map(e=>(0,t.jsx)("span",{style:{position:"absolute",left:`${e.x}px`,top:`${e.y}px`,width:"20px",height:"20px",borderRadius:"50%",background:"radial-gradient(circle, rgba(255, 255, 255, 0.4) 0%, rgba(255, 255, 255, 0) 70%)",pointerEvents:"none",animation:"ripple-animation 0.6s ease-out"}},e.id))})]})})})}var b=e.i(66065);e.s(["BookingButton",0,function(){return(0,t.jsx)(g,{label:"Rendez-vous",labelColor:"var(--gold-2)",ariaLabel:`Prendre rendez-vous : appeler le salon au ${b.B.phone.display}`,onClick:()=>{window.location.href=b.B.phone.tel}})}],23244)},93482,e=>{"use strict";var t=e.i(43476),r=e.i(71645);let o=(e,t)=>e.toFixed(t).replace(".",",");e.s(["CountUp",0,function({value:e,decimals:i=0}){let s=(0,r.useRef)(null),[a,n]=(0,r.useState)(o(e,i));return(0,r.useEffect)(()=>{let t=s.current;if(!t||window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;let r=0,a=new IntersectionObserver(([t])=>{if(!t.isIntersecting)return;a.disconnect();let s=performance.now(),l=t=>{let a=Math.min((t-s)/1800,1);n(o(e*(1-Math.pow(1-a,3)),i)),a<1&&(r=requestAnimationFrame(l))};r=requestAnimationFrame(l)},{threshold:.6});return a.observe(t),()=>{a.disconnect(),cancelAnimationFrame(r)}},[e,i]),(0,t.jsx)("span",{ref:s,className:"facts__num",children:a})}])},73282,e=>{"use strict";var t=e.i(43476),r=e.i(56420);let o={name:"map-pin",size:24,node:[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]};o.node;let i=(0,r.f)(o);var s=e.i(75387),a=e.i(71645),n=e.i(45157),l=e.i(47163),c=e.i(66065);e.s(["FloatingActions",0,function(){let[e,r]=(0,a.useState)(!1);return(0,a.useEffect)(()=>{let e=()=>r(window.scrollY>.6*window.innerHeight);return e(),window.addEventListener("scroll",e,{passive:!0}),()=>window.removeEventListener("scroll",e)},[]),(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:(0,l.f)("fab",e&&"is-visible"),"aria-label":"Contact rapide",children:[(0,t.jsx)("a",{href:c.B.whatsapp,target:"_blank",rel:"noopener",className:"fab__btn fab__btn--wa","aria-label":"Écrire sur WhatsApp",children:(0,t.jsx)(n.B,{})}),(0,t.jsx)("a",{href:c.B.phone.tel,className:"fab__btn fab__btn--call","aria-label":"Appeler le salon",children:(0,t.jsx)(s.f,{})})]}),(0,t.jsxs)("nav",{className:(0,l.f)("mobile-bar",e&&"is-visible"),"aria-label":"Contact rapide",children:[(0,t.jsxs)("a",{href:c.B.phone.tel,className:"mobile-bar__item mobile-bar__item--call",children:[(0,t.jsx)(s.f,{"aria-hidden":"true"}),(0,t.jsx)("span",{children:"Appeler"})]}),(0,t.jsxs)("a",{href:c.B.whatsapp,target:"_blank",rel:"noopener",className:"mobile-bar__item mobile-bar__item--wa",children:[(0,t.jsx)(n.B,{}),(0,t.jsx)("span",{children:"WhatsApp"})]}),(0,t.jsxs)("a",{href:c.B.directions,target:"_blank",rel:"noopener",className:"mobile-bar__item",children:[(0,t.jsx)(i,{"aria-hidden":"true"}),(0,t.jsx)("span",{children:"Itinéraire"})]})]})]})}],73282)},45179,e=>{"use strict";var t=e.i(43476),r=e.i(56420);let o={name:"chevron-left",size:24,node:[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]};o.node;let i=(0,r.f)(o),s={name:"chevron-right",size:24,node:[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]};s.node;let a=(0,r.f)(s),n={name:"x",size:24,node:[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]};n.node;let l=(0,r.f)(n);var c=e.i(71645),d=e.i(47163),u=e.i(66065);let h=e=>{let t=e.getBoundingClientRect();return{left:t.left,top:t.top,width:t.width,height:t.height}},p=(e,t)=>({left:`${e.left}px`,top:`${e.top}px`,width:`${e.width}px`,height:`${e.height}px`,borderRadius:`${t}px`});e.s(["Galerie",0,function(){let[e,r]=(0,c.useState)(null),[o,s]=(0,c.useState)(!1),[n,m]=(0,c.useState)(!1),f=(0,c.useRef)([]),g=(0,c.useRef)(null),b=(0,c.useRef)(null),x=(0,c.useRef)(null),v=(0,c.useRef)(null),w=(0,c.useRef)(null),y=(0,c.useRef)(0),_=(0,c.useCallback)(e=>{let t=f.current[e]?.querySelector("img"),r=t&&t.naturalWidth?t.naturalWidth/t.naturalHeight:4/3,o=window.innerWidth<600,i=window.innerWidth-(o?24:180),s=window.innerHeight-(o?170:120),a=i,n=a/r;return n>s&&(a=(n=s)*r),{left:(window.innerWidth-a)/2,top:(window.innerHeight-n)/2,width:a,height:n}},[]),k=(0,c.useCallback)((e,t,r,o)=>{let i=g.current;return i?(Object.assign(i.style,p(t,o)),v.current=t,window.matchMedia("(prefers-reduced-motion: reduce)").matches)?Promise.resolve():i.animate([p(e,r),p(t,o)],{duration:620,easing:"cubic-bezier(.22,.8,.2,1)"}).finished.then(()=>void 0).catch(()=>void 0):Promise.resolve()},[]);(0,c.useLayoutEffect)(()=>{let t=x.current;if(x.current=e,null===e)return;let r=f.current[e],o=_(e);null===t&&r?k(h(r),o,14,12):k(v.current??o,o,12,12)},[e,_,k]);let z=(0,c.useCallback)(async()=>{if(null===e||n)return;m(!0),s(!1);let t=f.current[e];t&&v.current&&await k(v.current,h(t),12,14),v.current=null,m(!1),r(null),w.current?.focus()},[e,n,k]),S=(0,c.useCallback)(e=>{n||r(t=>null===t?t:(t+e+u.M.length)%u.M.length)},[n]),R=null!==e;(0,c.useEffect)(()=>{if(!R)return;let e=window.innerWidth-document.documentElement.clientWidth;document.body.style.overflow="hidden",document.body.style.paddingRight=`${e}px`;let t=requestAnimationFrame(()=>s(!0));return b.current?.focus({preventScroll:!0}),()=>{cancelAnimationFrame(t),document.body.style.overflow="",document.body.style.paddingRight=""}},[R]),(0,c.useEffect)(()=>{if(!R)return;let t=e=>{"Escape"===e.key&&z(),"ArrowLeft"===e.key&&S(-1),"ArrowRight"===e.key&&S(1)},r=()=>{if(null===e||!g.current)return;let t=_(e);Object.assign(g.current.style,p(t,12)),v.current=t};return document.addEventListener("keydown",t),window.addEventListener("resize",r),()=>{document.removeEventListener("keydown",t),window.removeEventListener("resize",r)}},[R,e,z,S,_]);let E=null!==e?u.M[e]:null;return(0,t.jsxs)("section",{className:"section galerie",id:"galerie",children:[(0,t.jsxs)("div",{className:"container",children:[(0,t.jsxs)("div",{className:"section-head section-head--light",children:[(0,t.jsx)("p",{className:"eyebrow reveal",children:"Galerie"}),(0,t.jsxs)("h2",{className:"h2 reveal",children:["L'univers ",(0,t.jsx)("em",{children:"Star Look"})]})]}),(0,t.jsx)("div",{className:"gallery",children:u.M.map((o,i)=>(0,t.jsx)("button",{ref:e=>{f.current[i]=e},type:"button",className:(0,d.f)("g reveal",o.className),style:{visibility:e===i?"hidden":void 0},onClick:()=>{null===e&&!n&&(w.current=document.activeElement,r(i))},"aria-label":`Agrandir : ${o.alt}`,children:(0,t.jsx)("img",{src:o.src,alt:o.alt,loading:"lazy"})},o.src))}),(0,t.jsxs)("p",{className:"gallery__note reveal",children:["Photos d'ambiance. Retrouvez les réalisations du salon sur"," ",(0,t.jsx)("a",{href:u.B.facebook,target:"_blank",rel:"noopener",children:"notre page Facebook"}),"."]})]}),(0,t.jsxs)("div",{className:(0,d.f)("lightbox",o&&"is-open"),role:"dialog","aria-modal":"true","aria-label":"Photo agrandie",hidden:!R,onTouchStart:e=>{y.current=e.touches[0].clientX},onTouchEnd:e=>{let t=e.changedTouches[0].clientX-y.current;Math.abs(t)>50&&S(t<0?1:-1)},children:[(0,t.jsx)("div",{className:"lightbox__backdrop",onClick:z}),(0,t.jsx)("div",{ref:g,className:"lightbox__frame",children:E&&(0,t.jsx)("img",{src:E.src,alt:E.alt})}),(0,t.jsx)("button",{ref:b,type:"button",className:"lightbox__close","aria-label":"Fermer",onClick:z,children:(0,t.jsx)(l,{size:32,strokeWidth:1.5})}),(0,t.jsx)("button",{type:"button",className:"lightbox__nav lightbox__nav--prev","aria-label":"Photo précédente",onClick:()=>S(-1),children:(0,t.jsx)(i,{size:28,strokeWidth:1.5})}),(0,t.jsx)("button",{type:"button",className:"lightbox__nav lightbox__nav--next","aria-label":"Photo suivante",onClick:()=>S(1),children:(0,t.jsx)(a,{size:28,strokeWidth:1.5})})]})]})}],45179)},42225,e=>{"use strict";var t=e.i(43476),r=e.i(71645);e.s(["HeroStars",0,function(){let e=(0,r.useRef)(null);return(0,r.useEffect)(()=>{let t=e.current;if(!t||window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;let r=t.getContext("2d");if(!r)return;let o=0,i=0,s=[],a=!0,n=0,l=()=>{let e=Math.min(window.devicePixelRatio||1,2);o=t.clientWidth,i=t.clientHeight,t.width=o*e,t.height=i*e,r.setTransform(e,0,0,e,0,0),s=Array.from({length:Math.round(Math.min(70,o*i/18e3))},()=>({x:Math.random()*o,y:Math.random()*i,r:1.6*Math.random()+.3,s:.25*Math.random()+.05,p:Math.random()*Math.PI*2,ps:.02*Math.random()+.008}))},c=()=>{if(a){for(let e of(r.clearRect(0,0,o,i),s)){e.y-=e.s,e.p+=e.ps,e.y<-5&&(e.y=i+5,e.x=Math.random()*o);let t=.25+.75*Math.abs(Math.sin(e.p));r.beginPath(),r.fillStyle=`rgba(230,200,145,${t})`,r.shadowColor="rgba(230,200,145,.9)",r.shadowBlur=6*e.r,r.arc(e.x,e.y,e.r,0,2*Math.PI),r.fill()}n=requestAnimationFrame(c)}};l(),window.addEventListener("resize",l);let d=new IntersectionObserver(([e])=>{let t=a;(a=e.isIntersecting)&&!t&&c()});return d.observe(t),c(),()=>{a=!1,cancelAnimationFrame(n),d.disconnect(),window.removeEventListener("resize",l)}},[]),(0,t.jsx)("canvas",{ref:e,className:"hero__stars","aria-hidden":"true"})}])},5766,e=>{"use strict";var t=e.i(43476),r=e.i(71645),o=e.i(66065);let i={Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6};function s(){try{let e=new Intl.DateTimeFormat("en-GB",{timeZone:"Africa/Tunis",weekday:"short",hour:"2-digit",minute:"2-digit",hour12:!1}).formatToParts(new Date),t=t=>e.find(e=>e.type===t)?.value??"";return{day:i[t("weekday")],minutes:parseInt(t("hour"),10)%24*60+parseInt(t("minute"),10)}}catch{return null}}function a(){let[e,t]=(0,r.useState)(null);return(0,r.useEffect)(()=>{t(s());let e=window.setInterval(()=>t(s()),6e4);return()=>window.clearInterval(e)},[]),e}var n=e.i(47163);e.s(["HoursList",0,function(){let e=a();return(0,t.jsx)("ul",{className:"hours",children:o.K.map(({day:r,label:i})=>(0,t.jsxs)("li",{className:(0,n.f)(e?.day===r&&"is-today"),children:[(0,t.jsx)("span",{children:i}),(0,t.jsxs)("span",{children:[o.B.hours.opens," – ",o.B.hours.closes]})]},r))})},"OpenStatusPill",0,function(){let e=function(e){if(!e)return{state:"unknown",text:"Ouvert 7j/7 · 9h30–22h"};let{openMinutes:t,closeMinutes:r}=o.B.hours;if(e.minutes>=t&&e.minutes<r){let t=r-e.minutes;return{state:"open",text:t<=60?`Ouvert \xb7 ferme dans ${t} min`:"Ouvert maintenant · jusqu'à 22h"}}return{state:"closed",text:e.minutes<t?"Fermé · ouvre à 9h30":"Fermé · ouvre demain à 9h30"}}(a());return(0,t.jsxs)("div",{className:(0,n.f)("status-pill","open"===e.state&&"is-open","closed"===e.state&&"is-closed"),children:[(0,t.jsx)("span",{className:"status-dot"}),(0,t.jsx)("span",{children:e.text})]})}],5766)},81545,e=>{"use strict";var t=e.i(71645);e.s(["RevealObserver",0,function(){return(0,t.useEffect)(()=>{let e=Array.from(document.querySelectorAll(".reveal, .score"));if(window.matchMedia("(prefers-reduced-motion: reduce)").matches||!("IntersectionObserver"in window))return void e.forEach(e=>e.classList.add("is-visible"));let t=new IntersectionObserver(e=>e.forEach(e=>{e.isIntersecting&&(e.target.classList.add("is-visible"),t.unobserve(e.target))}),{threshold:.15,rootMargin:"0px 0px -40px 0px"});return e.forEach(e=>t.observe(e)),()=>t.disconnect()},[]),null}])},17551,e=>{"use strict";var t=e.i(43476),r=e.i(75387),o=e.i(71645),i=e.i(45157),s=e.i(47163),a=e.i(66065);e.s(["SiteHeader",0,function(){let[e,n]=(0,o.useState)(!1),[l,c]=(0,o.useState)(!1),[d,u]=(0,o.useState)(null);return(0,o.useEffect)(()=>{let e=()=>n(window.scrollY>40);return e(),window.addEventListener("scroll",e,{passive:!0}),()=>window.removeEventListener("scroll",e)},[]),(0,o.useEffect)(()=>{let e=a.o.map(e=>document.querySelector(e.href)).filter(e=>!!e),t=new IntersectionObserver(e=>e.forEach(e=>{e.isIntersecting&&u(`#${e.target.id}`)}),{rootMargin:"-45% 0px -50% 0px"});return e.forEach(e=>t.observe(e)),()=>t.disconnect()},[]),(0,o.useEffect)(()=>{document.body.style.overflow=l?"hidden":"";let e=e=>"Escape"===e.key&&c(!1);return document.addEventListener("keydown",e),()=>document.removeEventListener("keydown",e)},[l]),(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("header",{className:(0,s.f)("nav",e&&"is-scrolled"),children:(0,t.jsxs)("div",{className:"nav__inner",children:[(0,t.jsxs)("a",{href:"#accueil",className:"brand","aria-label":"Star Look — accueil",children:[(0,t.jsx)(i.O,{className:"brand__star"}),(0,t.jsx)("span",{className:"brand__name",children:"Star Look"})]}),(0,t.jsx)("nav",{className:"nav__links","aria-label":"Navigation principale",children:a.o.map(e=>(0,t.jsx)("a",{href:e.href,className:(0,s.f)(d===e.href&&"is-active"),children:e.label},e.href))}),(0,t.jsxs)("a",{href:a.B.phone.tel,className:"btn btn--gold nav__cta",children:[(0,t.jsx)(r.f,{"aria-hidden":"true"}),"Réserver"]}),(0,t.jsxs)("button",{type:"button",className:"burger","aria-label":l?"Fermer le menu":"Ouvrir le menu","aria-expanded":l,"aria-controls":"mobile-menu",onClick:()=>c(e=>!e),children:[(0,t.jsx)("span",{}),(0,t.jsx)("span",{})]})]})}),(0,t.jsxs)("div",{id:"mobile-menu",className:(0,s.f)("mobile-menu",l&&"is-open"),"aria-hidden":!l,children:[(0,t.jsx)("nav",{"aria-label":"Navigation mobile",children:a.o.map(e=>(0,t.jsx)("a",{href:e.href,onClick:()=>c(!1),tabIndex:l?0:-1,children:e.label},e.href))}),(0,t.jsxs)("div",{className:"mobile-menu__foot",children:[(0,t.jsxs)("a",{href:a.B.phone.tel,className:"btn btn--gold",tabIndex:l?0:-1,children:["Appeler le ",a.B.phone.display]}),(0,t.jsx)("a",{href:a.B.whatsapp,target:"_blank",rel:"noopener",className:"btn btn--ghost",tabIndex:l?0:-1,children:"WhatsApp"})]})]})]})}])},66065,e=>{"use strict";e.s(["M",0,[{src:"assets/img/g-salon.webp",alt:"Fauteuils de salon de coiffure",className:"g--a"},{src:"assets/img/g-cils.webp",alt:"Gros plan de longs cils",className:"g--b"},{src:"assets/img/g-boucles.webp",alt:"Mise en plis au fer à friser",className:"g--c"},{src:"assets/img/g-ongles.webp",alt:"Ongles manucurés rose pâle",className:"g--d"},{src:"assets/img/g-produits.webp",alt:"Produits cosmétiques",className:"g--e"},{src:"assets/img/g-coiffage.webp",alt:"Cliente en cours de coiffage",className:"g--f"}],"o",0,[{href:"#maison",label:"La maison"},{href:"#prestations",label:"Prestations"},{href:"#galerie",label:"Galerie"},{href:"#avis",label:"Avis"},{href:"#contact",label:"Contact"}],"B",0,{name:"Coiffure & Esthétique Star Look",shortName:"Star Look",category:"Institut de beauté",address:{line1:"2ème étage, Immeuble El Handouz",line2:"GP1, Hammam Sousse 4011",locality:"Hammam Sousse",postalCode:"4011",country:"TN",plusCode:"VJ42+8M Hammam Sousse"},geo:{lat:35.8557785,lng:10.6016796},phone:{display:"52 644 344",international:"+216 52 644 344",tel:"tel:+21652644344"},whatsapp:"https://wa.me/21652644344",facebook:"https://www.facebook.com/STARLOOK.TN/",googleMaps:"https://www.google.com/maps/place/?q=place_id:ChIJU4LqdWuK_RIRtEGFoNm54sE",directions:"https://www.google.com/maps/dir/?api=1&destination=35.8557785%2C10.6016796&destination_place_id=ChIJU4LqdWuK_RIRtEGFoNm54sE",mapEmbed:"https://maps.google.com/maps?q=Coiffure%20%26%20Esth%C3%A9tique%20Star%20Look%2C%20Hammam%20Sousse&ll=35.8557785,10.6016796&z=17&hl=fr&output=embed",hours:{opens:"09:30",closes:"22:00",openMinutes:570,closeMinutes:1320},rating:{value:4.6,count:241,distribution:[{stars:5,count:208},{stars:4,count:7},{stars:3,count:4},{stars:2,count:4},{stars:1,count:18}],topics:[["protéines",42],["prix",9],["microblading",8],["kératine",7],["travail",7],["cils",6],["équipe",5],["cheveux",5]]}},"K",0,[{day:1,label:"Lundi"},{day:2,label:"Mardi"},{day:3,label:"Mercredi"},{day:4,label:"Jeudi"},{day:5,label:"Vendredi"},{day:6,label:"Samedi"},{day:0,label:"Dimanche"}]])},47163,e=>{"use strict";var t;let r,o,i,s,a,n=(e=new Map,t=null,r)=>({nextPart:e,validators:t,classGroupId:r}),l=[],c=(e,t,r)=>{if(0==e.length-t)return r.classGroupId;let o=e[t],i=r.nextPart.get(o);if(i){let r=c(e,t+1,i);if(r)return r}let s=r.validators;if(null===s)return;let a=0===t?e.join("-"):e.slice(t).join("-"),n=s.length;for(let e=0;e<n;e++){let t=s[e];if(t.validator(a))return t.classGroupId}},d=(e,t)=>{let r=n();for(let o in e)u(e[o],r,o,t);return r},u=(e,t,r,o)=>{let i=e.length;for(let s=0;s<i;s++)h(e[s],t,r,o)},h=(e,t,r,o)=>{"string"==typeof e?p(e,t,r):"function"==typeof e?m(e,t,r,o):f(e,t,r,o)},p=(e,t,r)=>{(""===e?t:g(t,e)).classGroupId=r},m=(e,t,r,o)=>{b(e)?u(e(o),t,r,o):(null===t.validators&&(t.validators=[]),t.validators.push({classGroupId:r,validator:e}))},f=(e,t,r,o)=>{let i=Object.entries(e),s=i.length;for(let e=0;e<s;e++){let[s,a]=i[e];u(a,g(t,s),r,o)}},g=(e,t)=>{let r=e,o=t.split("-"),i=o.length;for(let e=0;e<i;e++){let t=o[e],i=r.nextPart.get(t);i||(i=n(),r.nextPart.set(t,i)),r=i}return r},b=e=>"isThemeGetter"in e&&!0===e.isThemeGetter,x=[],v=(e,t,r,o,i)=>({modifiers:e,hasImportantModifier:t,baseClassName:r,maybePostfixModifierPosition:o,isExternal:i}),w=/\s+/,y=e=>{let t;if("string"==typeof e)return e;let r="";for(let o=0;o<e.length;o++)e[o]&&(t=y(e[o]))&&(r&&(r+=" "),r+=t);return r},_=[],k=e=>{let t=t=>t[e]||_;return t.isThemeGetter=!0,t.themeKey=e,t},z=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,S=/^\((?:(\w[\w-]*):)?(.+)\)$/i,R=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,E=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,B=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,U=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix|color|light-dark)\(.+\)$/,j=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,A=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,V=e=>R.test(e),C=e=>!!e&&!Number.isNaN(Number(e)),T=e=>!!e&&Number.isInteger(Number(e)),M=e=>e.endsWith("%")&&C(e.slice(0,-1)),I=e=>E.test(e),L=()=>!0,N=e=>B.test(e)&&!U.test(e),P=()=>!1,W=e=>j.test(e),O=e=>A.test(e),F=e=>!$(e)&&!Q(e),D=e=>e.startsWith("@container")&&("/"===e[10]&&void 0!==e[11]||"s"===e[11]&&void 0!==e[16]&&e.startsWith("-size/",10)||"n"===e[11]&&void 0!==e[18]&&e.startsWith("-normal/",10)),G=e=>en(e,eu,P),$=e=>z.test(e),H=e=>en(e,eh,N),q=e=>en(e,ep,C),X=e=>en(e,ef,L),Y=e=>en(e,em,P),K=e=>en(e,ec,P),Z=e=>en(e,ed,O),J=e=>en(e,eg,W),Q=e=>S.test(e),ee=e=>el(e,eh),et=e=>el(e,em),er=e=>el(e,ec),eo=e=>el(e,eu),ei=e=>el(e,ed),es=e=>el(e,eg,!0),ea=e=>el(e,ef,!0),en=(e,t,r)=>{let o=z.exec(e);return!!o&&(o[1]?t(o[1]):r(o[2]))},el=(e,t,r=!1)=>{let o=S.exec(e);return!!o&&(o[1]?t(o[1]):r)},ec=e=>"position"===e||"percentage"===e,ed=e=>"image"===e||"url"===e,eu=e=>"length"===e||"size"===e||"bg-size"===e,eh=e=>"length"===e,ep=e=>"number"===e,em=e=>"family-name"===e,ef=e=>"number"===e||"weight"===e,eg=e=>"shadow"===e,eb=(t=()=>{let e=k("color"),t=k("font"),r=k("text"),o=k("font-weight"),i=k("tracking"),s=k("leading"),a=k("breakpoint"),n=k("container"),l=k("spacing"),c=k("radius"),d=k("shadow"),u=k("inset-shadow"),h=k("text-shadow"),p=k("drop-shadow"),m=k("blur"),f=k("perspective"),g=k("aspect"),b=k("ease"),x=k("animate"),v=()=>["auto","avoid","all","avoid-page","page","left","right","column"],w=()=>["center","top","bottom","left","right","top-left","left-top","top-right","right-top","bottom-right","right-bottom","bottom-left","left-bottom"],y=()=>[...w(),Q,$],_=()=>["auto","hidden","clip","visible","scroll"],z=()=>["auto","contain","none"],S=()=>[Q,$,l],R=()=>[V,"full","auto",...S()],E=()=>[T,"none","subgrid",Q,$],B=()=>["auto",{span:["full",T,Q,$]},T,Q,$],U=()=>[T,"auto",Q,$],j=()=>["auto","min","max","fr",Q,$],A=()=>["start","end","center","between","around","evenly","stretch","baseline","center-safe","end-safe"],N=()=>["start","end","center","stretch","center-safe","end-safe"],P=()=>["auto",...S()],W=()=>[V,"auto","full","dvw","dvh","lvw","lvh","svw","svh","min","max","fit",...S()],O=()=>[n,V,"screen","full","dvw","lvw","svw","min","max","fit",...S()],en=()=>[V,"screen","full","lh","dvh","lvh","svh","min","max","fit",...S()],el=()=>[e,Q,$],ec=()=>[...w(),er,K,{position:[Q,$]}],ed=()=>["no-repeat",{repeat:["","x","y","space","round"]}],eu=()=>["auto","cover","contain",eo,G,{size:[Q,$]}],eh=()=>[M,ee,H],ep=()=>["","none","full",c,Q,$],em=()=>["",C,ee,H],ef=()=>["solid","dashed","dotted","double"],eg=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],eb=()=>[C,M,er,K],ex=()=>["","none",m,Q,$],ev=()=>["none",C,Q,$],ew=()=>["none",C,Q,$],ey=()=>[C,Q,$],e_=()=>[V,"full",...S()];return{cacheSize:500,theme:{animate:["spin","ping","pulse","bounce"],aspect:["video"],blur:[I],breakpoint:[I],color:[L],container:[I],"drop-shadow":[I],ease:["in","out","in-out"],font:[F],"font-weight":["thin","extralight","light","normal","medium","semibold","bold","extrabold","black"],"inset-shadow":[I],leading:["none","tight","snug","normal","relaxed","loose"],perspective:["dramatic","near","normal","midrange","distant","none"],radius:[I],shadow:[I],spacing:["px",C],text:[I],"text-shadow":[I],tracking:["tighter","tight","normal","wide","wider","widest"]},classGroups:{aspect:[{aspect:["auto","square",V,$,Q,g]}],container:["container"],"container-type":[{"@container":["","normal","size",Q,$]}],"container-named":[D],columns:[{columns:[C,"auto",$,Q,n]}],"break-after":[{"break-after":v()}],"break-before":[{"break-before":v()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],sr:["sr-only","not-sr-only"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:y()}],overflow:[{overflow:_()}],"overflow-x":[{"overflow-x":_()}],"overflow-y":[{"overflow-y":_()}],overscroll:[{overscroll:z()}],"overscroll-x":[{"overscroll-x":z()}],"overscroll-y":[{"overscroll-y":z()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:R()}],"inset-x":[{"inset-x":R()}],"inset-y":[{"inset-y":R()}],start:[{"inset-s":R(),start:R()}],end:[{"inset-e":R(),end:R()}],"inset-bs":[{"inset-bs":R()}],"inset-be":[{"inset-be":R()}],top:[{top:R()}],right:[{right:R()}],bottom:[{bottom:R()}],left:[{left:R()}],visibility:["visible","invisible","collapse"],z:[{z:[T,"auto",Q,$]}],basis:[{basis:[V,"full","auto",n,...S()]}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["nowrap","wrap","wrap-reverse"]}],flex:[{flex:[C,V,"auto","initial","none",$]}],grow:[{grow:["",C,Q,$]}],shrink:[{shrink:["",C,Q,$]}],order:[{order:[T,"first","last","none",Q,$]}],"grid-cols":[{"grid-cols":E()}],"col-start-end":[{col:B()}],"col-start":[{"col-start":U()}],"col-end":[{"col-end":U()}],"grid-rows":[{"grid-rows":E()}],"row-start-end":[{row:B()}],"row-start":[{"row-start":U()}],"row-end":[{"row-end":U()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":j()}],"auto-rows":[{"auto-rows":j()}],gap:[{gap:S()}],"gap-x":[{"gap-x":S()}],"gap-y":[{"gap-y":S()}],"justify-content":[{justify:[...A(),"normal"]}],"justify-items":[{"justify-items":[...N(),"normal"]}],"justify-self":[{"justify-self":["auto",...N()]}],"align-content":[{content:["normal",...A()]}],"align-items":[{items:[...N(),{baseline:["","last"]}]}],"align-self":[{self:["auto",...N(),{baseline:["","last"]}]}],"place-content":[{"place-content":A()}],"place-items":[{"place-items":[...N(),"baseline"]}],"place-self":[{"place-self":["auto",...N()]}],p:[{p:S()}],px:[{px:S()}],py:[{py:S()}],ps:[{ps:S()}],pe:[{pe:S()}],pbs:[{pbs:S()}],pbe:[{pbe:S()}],pt:[{pt:S()}],pr:[{pr:S()}],pb:[{pb:S()}],pl:[{pl:S()}],m:[{m:P()}],mx:[{mx:P()}],my:[{my:P()}],ms:[{ms:P()}],me:[{me:P()}],mbs:[{mbs:P()}],mbe:[{mbe:P()}],mt:[{mt:P()}],mr:[{mr:P()}],mb:[{mb:P()}],ml:[{ml:P()}],"space-x":[{"space-x":S()}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":S()}],"space-y-reverse":["space-y-reverse"],size:[{size:W()}],"inline-size":[{inline:["auto",...O()]}],"min-inline-size":[{"min-inline":["auto",...O()]}],"max-inline-size":[{"max-inline":["none",...O()]}],"block-size":[{block:["auto",...en()]}],"min-block-size":[{"min-block":["auto",...en()]}],"max-block-size":[{"max-block":["none",...en()]}],w:[{w:[n,"screen",...W()]}],"min-w":[{"min-w":[n,"screen","none",...W()]}],"max-w":[{"max-w":[n,"screen","none","prose",{screen:[a]},...W()]}],h:[{h:["screen","lh",...W()]}],"min-h":[{"min-h":["screen","lh","none",...W()]}],"max-h":[{"max-h":["screen","lh","none",...W()]}],"font-size":[{text:["base",r,ee,H]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:[o,ea,X]}],"font-stretch":[{"font-stretch":["ultra-condensed","extra-condensed","condensed","semi-condensed","normal","semi-expanded","expanded","extra-expanded","ultra-expanded",M,$]}],"font-family":[{font:[et,Y,t]}],"font-features":[{"font-features":[$]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:[i,Q,$]}],"line-clamp":[{"line-clamp":[C,"none",Q,q]}],leading:[{leading:["none",s,...S()]}],"list-image":[{"list-image":["none",Q,$]}],"list-style-position":[{list:["inside","outside"]}],"list-style-type":[{list:["disc","decimal","none",Q,$]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"placeholder-color":[{placeholder:el()}],"text-color":[{text:el()}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...ef(),"wavy"]}],"text-decoration-thickness":[{decoration:[C,"from-font","auto",Q,H]}],"text-decoration-color":[{decoration:el()}],"underline-offset":[{"underline-offset":[C,"auto",Q,$]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:S()}],"tab-size":[{tab:[T,Q,$]}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",Q,$]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],wrap:[{wrap:["break-word","anywhere","normal"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",Q,$]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:ec()}],"bg-repeat":[{bg:ed()}],"bg-size":[{bg:eu()}],"bg-image":[{bg:["none",{linear:[{to:["t","tr","r","br","b","bl","l","tl"]},T,Q,$],radial:["",Q,$],conic:["",T,Q,$]},ei,Z]}],"bg-color":[{bg:el()}],"gradient-from-pos":[{from:eh()}],"gradient-via-pos":[{via:eh()}],"gradient-to-pos":[{to:eh()}],"gradient-from":[{from:el()}],"gradient-via":[{via:el()}],"gradient-to":[{to:el()}],rounded:[{rounded:ep()}],"rounded-s":[{"rounded-s":ep()}],"rounded-e":[{"rounded-e":ep()}],"rounded-t":[{"rounded-t":ep()}],"rounded-r":[{"rounded-r":ep()}],"rounded-b":[{"rounded-b":ep()}],"rounded-l":[{"rounded-l":ep()}],"rounded-ss":[{"rounded-ss":ep()}],"rounded-se":[{"rounded-se":ep()}],"rounded-ee":[{"rounded-ee":ep()}],"rounded-es":[{"rounded-es":ep()}],"rounded-tl":[{"rounded-tl":ep()}],"rounded-tr":[{"rounded-tr":ep()}],"rounded-br":[{"rounded-br":ep()}],"rounded-bl":[{"rounded-bl":ep()}],"border-w":[{border:em()}],"border-w-x":[{"border-x":em()}],"border-w-y":[{"border-y":em()}],"border-w-s":[{"border-s":em()}],"border-w-e":[{"border-e":em()}],"border-w-bs":[{"border-bs":em()}],"border-w-be":[{"border-be":em()}],"border-w-t":[{"border-t":em()}],"border-w-r":[{"border-r":em()}],"border-w-b":[{"border-b":em()}],"border-w-l":[{"border-l":em()}],"divide-x":[{"divide-x":em()}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":em()}],"divide-y-reverse":["divide-y-reverse"],"border-style":[{border:[...ef(),"hidden","none"]}],"divide-style":[{divide:[...ef(),"hidden","none"]}],"border-color":[{border:el()}],"border-color-x":[{"border-x":el()}],"border-color-y":[{"border-y":el()}],"border-color-s":[{"border-s":el()}],"border-color-e":[{"border-e":el()}],"border-color-bs":[{"border-bs":el()}],"border-color-be":[{"border-be":el()}],"border-color-t":[{"border-t":el()}],"border-color-r":[{"border-r":el()}],"border-color-b":[{"border-b":el()}],"border-color-l":[{"border-l":el()}],"divide-color":[{divide:el()}],"outline-style":[{outline:[...ef(),"none","hidden"]}],"outline-offset":[{"outline-offset":[C,Q,$]}],"outline-w":[{outline:["",C,ee,H]}],"outline-color":[{outline:el()}],shadow:[{shadow:["","inner","none",d,es,J]}],"shadow-color":[{shadow:el()}],"inset-shadow":[{"inset-shadow":["none",u,es,J]}],"inset-shadow-color":[{"inset-shadow":el()}],"ring-w":[{ring:em()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:el()}],"ring-offset-w":[{"ring-offset":[C,H]}],"ring-offset-color":[{"ring-offset":el()}],"inset-ring-w":[{"inset-ring":em()}],"inset-ring-color":[{"inset-ring":el()}],"text-shadow":[{"text-shadow":["none",h,es,J]}],"text-shadow-color":[{"text-shadow":el()}],opacity:[{opacity:[C,Q,$]}],"mix-blend":[{"mix-blend":[...eg(),"plus-darker","plus-lighter"]}],"bg-blend":[{"bg-blend":eg()}],"mask-clip":[{"mask-clip":["border","padding","content","fill","stroke","view"]},"mask-no-clip"],"mask-composite":[{mask:["add","subtract","intersect","exclude"]}],"mask-image-linear-pos":[{"mask-linear":[C]}],"mask-image-linear-from-pos":[{"mask-linear-from":eb()}],"mask-image-linear-to-pos":[{"mask-linear-to":eb()}],"mask-image-linear-from-color":[{"mask-linear-from":el()}],"mask-image-linear-to-color":[{"mask-linear-to":el()}],"mask-image-t-from-pos":[{"mask-t-from":eb()}],"mask-image-t-to-pos":[{"mask-t-to":eb()}],"mask-image-t-from-color":[{"mask-t-from":el()}],"mask-image-t-to-color":[{"mask-t-to":el()}],"mask-image-r-from-pos":[{"mask-r-from":eb()}],"mask-image-r-to-pos":[{"mask-r-to":eb()}],"mask-image-r-from-color":[{"mask-r-from":el()}],"mask-image-r-to-color":[{"mask-r-to":el()}],"mask-image-b-from-pos":[{"mask-b-from":eb()}],"mask-image-b-to-pos":[{"mask-b-to":eb()}],"mask-image-b-from-color":[{"mask-b-from":el()}],"mask-image-b-to-color":[{"mask-b-to":el()}],"mask-image-l-from-pos":[{"mask-l-from":eb()}],"mask-image-l-to-pos":[{"mask-l-to":eb()}],"mask-image-l-from-color":[{"mask-l-from":el()}],"mask-image-l-to-color":[{"mask-l-to":el()}],"mask-image-x-from-pos":[{"mask-x-from":eb()}],"mask-image-x-to-pos":[{"mask-x-to":eb()}],"mask-image-x-from-color":[{"mask-x-from":el()}],"mask-image-x-to-color":[{"mask-x-to":el()}],"mask-image-y-from-pos":[{"mask-y-from":eb()}],"mask-image-y-to-pos":[{"mask-y-to":eb()}],"mask-image-y-from-color":[{"mask-y-from":el()}],"mask-image-y-to-color":[{"mask-y-to":el()}],"mask-image-radial":[{"mask-radial":[Q,$]}],"mask-image-radial-from-pos":[{"mask-radial-from":eb()}],"mask-image-radial-to-pos":[{"mask-radial-to":eb()}],"mask-image-radial-from-color":[{"mask-radial-from":el()}],"mask-image-radial-to-color":[{"mask-radial-to":el()}],"mask-image-radial-shape":[{"mask-radial":["circle","ellipse"]}],"mask-image-radial-size":[{"mask-radial":[{closest:["side","corner"],farthest:["side","corner"]}]}],"mask-image-radial-pos":[{"mask-radial-at":w()}],"mask-image-conic-pos":[{"mask-conic":[C]}],"mask-image-conic-from-pos":[{"mask-conic-from":eb()}],"mask-image-conic-to-pos":[{"mask-conic-to":eb()}],"mask-image-conic-from-color":[{"mask-conic-from":el()}],"mask-image-conic-to-color":[{"mask-conic-to":el()}],"mask-mode":[{mask:["alpha","luminance","match"]}],"mask-origin":[{"mask-origin":["border","padding","content","fill","stroke","view"]}],"mask-position":[{mask:ec()}],"mask-repeat":[{mask:ed()}],"mask-size":[{mask:eu()}],"mask-type":[{"mask-type":["alpha","luminance"]}],"mask-image":[{mask:["none",Q,$]}],filter:[{filter:["","none",Q,$]}],blur:[{blur:ex()}],brightness:[{brightness:[C,Q,$]}],contrast:[{contrast:[C,Q,$]}],"drop-shadow":[{"drop-shadow":["","none",p,es,J]}],"drop-shadow-color":[{"drop-shadow":el()}],grayscale:[{grayscale:["",C,Q,$]}],"hue-rotate":[{"hue-rotate":[C,Q,$]}],invert:[{invert:["",C,Q,$]}],saturate:[{saturate:[C,Q,$]}],sepia:[{sepia:["",C,Q,$]}],"backdrop-filter":[{"backdrop-filter":["","none",Q,$]}],"backdrop-blur":[{"backdrop-blur":ex()}],"backdrop-brightness":[{"backdrop-brightness":[C,Q,$]}],"backdrop-contrast":[{"backdrop-contrast":[C,Q,$]}],"backdrop-grayscale":[{"backdrop-grayscale":["",C,Q,$]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[C,Q,$]}],"backdrop-invert":[{"backdrop-invert":["",C,Q,$]}],"backdrop-opacity":[{"backdrop-opacity":[C,Q,$]}],"backdrop-saturate":[{"backdrop-saturate":[C,Q,$]}],"backdrop-sepia":[{"backdrop-sepia":["",C,Q,$]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":S()}],"border-spacing-x":[{"border-spacing-x":S()}],"border-spacing-y":[{"border-spacing-y":S()}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["","all","colors","opacity","shadow","transform","none",Q,$]}],"transition-behavior":[{transition:["normal","discrete"]}],duration:[{duration:[C,"initial",Q,$]}],ease:[{ease:["linear","initial",b,Q,$]}],delay:[{delay:[C,Q,$]}],animate:[{animate:["none",x,Q,$]}],backface:[{backface:["hidden","visible"]}],perspective:[{perspective:[f,Q,$]}],"perspective-origin":[{"perspective-origin":y()}],rotate:[{rotate:ev()}],"rotate-x":[{"rotate-x":ev()}],"rotate-y":[{"rotate-y":ev()}],"rotate-z":[{"rotate-z":ev()}],scale:[{scale:ew()}],"scale-x":[{"scale-x":ew()}],"scale-y":[{"scale-y":ew()}],"scale-z":[{"scale-z":ew()}],"scale-3d":["scale-3d"],skew:[{skew:ey()}],"skew-x":[{"skew-x":ey()}],"skew-y":[{"skew-y":ey()}],transform:[{transform:[Q,$,"","none","gpu","cpu"]}],"transform-origin":[{origin:y()}],"transform-style":[{transform:["3d","flat"]}],translate:[{translate:e_()}],"translate-x":[{"translate-x":e_()}],"translate-y":[{"translate-y":e_()}],"translate-z":[{"translate-z":e_()}],"translate-none":["translate-none"],zoom:[{zoom:[T,Q,$]}],accent:[{accent:el()}],appearance:[{appearance:["none","auto"]}],"caret-color":[{caret:el()}],"color-scheme":[{scheme:["normal","dark","light","light-dark","only-dark","only-light"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",Q,$]}],"field-sizing":[{"field-sizing":["fixed","content"]}],"pointer-events":[{"pointer-events":["auto","none"]}],resize:[{resize:["none","","y","x"]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scrollbar-thumb-color":[{"scrollbar-thumb":el()}],"scrollbar-track-color":[{"scrollbar-track":el()}],"scrollbar-gutter":[{"scrollbar-gutter":["auto","stable","both"]}],"scrollbar-w":[{scrollbar:["auto","thin","none"]}],"scroll-m":[{"scroll-m":S()}],"scroll-mx":[{"scroll-mx":S()}],"scroll-my":[{"scroll-my":S()}],"scroll-ms":[{"scroll-ms":S()}],"scroll-me":[{"scroll-me":S()}],"scroll-mbs":[{"scroll-mbs":S()}],"scroll-mbe":[{"scroll-mbe":S()}],"scroll-mt":[{"scroll-mt":S()}],"scroll-mr":[{"scroll-mr":S()}],"scroll-mb":[{"scroll-mb":S()}],"scroll-ml":[{"scroll-ml":S()}],"scroll-p":[{"scroll-p":S()}],"scroll-px":[{"scroll-px":S()}],"scroll-py":[{"scroll-py":S()}],"scroll-ps":[{"scroll-ps":S()}],"scroll-pe":[{"scroll-pe":S()}],"scroll-pbs":[{"scroll-pbs":S()}],"scroll-pbe":[{"scroll-pbe":S()}],"scroll-pt":[{"scroll-pt":S()}],"scroll-pr":[{"scroll-pr":S()}],"scroll-pb":[{"scroll-pb":S()}],"scroll-pl":[{"scroll-pl":S()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",Q,$]}],fill:[{fill:["none",...el()]}],"stroke-w":[{stroke:[C,ee,H,q]}],stroke:[{stroke:["none",...el()]}],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{"container-named":["container-type"],overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","inset-bs","inset-be","start","end","top","right","bottom","left"],"inset-x":["start","end","right","left"],"inset-y":["inset-bs","inset-be","top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pbs","pbe","pt","pr","pb","pl"],px:["ps","pe","pr","pl"],py:["pbs","pbe","pt","pb"],m:["mx","my","ms","me","mbs","mbe","mt","mr","mb","ml"],mx:["ms","me","mr","ml"],my:["mbs","mbe","mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-x","border-w-y","border-w-s","border-w-e","border-w-bs","border-w-be","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-s","border-w-e","border-w-r","border-w-l"],"border-w-y":["border-w-bs","border-w-be","border-w-t","border-w-b"],"border-color":["border-color-x","border-color-y","border-color-s","border-color-e","border-color-bs","border-color-be","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-s","border-color-e","border-color-r","border-color-l"],"border-color-y":["border-color-bs","border-color-be","border-color-t","border-color-b"],translate:["translate-x","translate-y","translate-none"],"translate-none":["translate","translate-x","translate-y","translate-z"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mbs","scroll-mbe","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-ms","scroll-me","scroll-mr","scroll-ml"],"scroll-my":["scroll-mbs","scroll-mbe","scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pbs","scroll-pbe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-ps","scroll-pe","scroll-pr","scroll-pl"],"scroll-py":["scroll-pbs","scroll-pbe","scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]},postfixLookupClassGroups:["container-type"],orderSensitiveModifiers:["*","**","after","backdrop","before","details-content","file","first-letter","first-line","marker","placeholder","selection"]}},a=e=>{let t=o(e);if(t)return t;let s=((e,t)=>{let{parseClassName:r,getClassGroupId:o,getConflictingClassGroupIds:i,sortModifiers:s,postfixLookupClassGroupIds:a}=t,n=[],l=e.trim().split(w),c="";for(let e=l.length-1;e>=0;e-=1){let t,d=l[e],{isExternal:u,modifiers:h,hasImportantModifier:p,baseClassName:m,maybePostfixModifierPosition:f}=r(d);if(u){c=d+(c.length>0?" "+c:c);continue}let g=!!f;if(g){let e=(t=o(m.substring(0,f)))&&a[t]?o(m):void 0;e&&e!==t&&(t=e,g=!1)}else t=o(m);if(!t){if(!g||!(t=o(m))){c=d+(c.length>0?" "+c:c);continue}g=!1}let b=0===h.length?"":1===h.length?h[0]:s(h).join(":"),x=p?b+"!":b,v=x+t;if(n.indexOf(v)>-1)continue;n.push(v);let w=i(t,g);for(let e=0;e<w.length;++e){let t=w[e];n.push(x+t)}c=d+(c.length>0?" "+c:c)}return c})(e,r);return i(e,s),s},s=e=>{var n;let u;return o=(r={cache:(e=>{if(e<1)return{get:()=>void 0,set:()=>{}};let t=0,r=Object.create(null),o=Object.create(null),i=(i,s)=>{r[i]=s,++t>e&&(t=0,o=r,r=Object.create(null))};return{get(e){let t=r[e];return void 0!==t?t:void 0!==(t=o[e])?(i(e,t),t):void 0},set(e,t){e in r?r[e]=t:i(e,t)}}})((n=[].reduce((e,t)=>t(e),t())).cacheSize),parseClassName:(e=>{let{prefix:t,experimentalParseClassName:r}=e,o=e=>{let t,r=[],o=0,i=0,s=0,a=e.length;for(let n=0;n<a;n++){let a=e[n];if(0===o&&0===i){if(":"===a){r.push(e.slice(s,n)),s=n+1;continue}if("/"===a){t=n;continue}}"["===a?o++:"]"===a?o--:"("===a?i++:")"===a&&i--}let n=0===r.length?e:e.slice(s),l=n,c=!1;return n.endsWith("!")?(l=n.slice(0,-1),c=!0):n.startsWith("!")&&(l=n.slice(1),c=!0),v(r,c,l,t&&t>s?t-s:void 0)};if(t){let e=t+":",r=o;o=t=>t.startsWith(e)?r(t.slice(e.length)):v(x,!1,t,void 0,!0)}if(r){let e=o;o=t=>r({className:t,parseClassName:e})}return o})(n),sortModifiers:(u=new Map,n.orderSensitiveModifiers.forEach((e,t)=>{u.set(e,1e6+t)}),e=>{let t=[],r=[];for(let o=0;o<e.length;o++){let i=e[o],s="["===i[0],a=u.has(i);s||a?(r.length>0&&(r.sort(),t.push(...r),r=[]),t.push(i)):r.push(i)}return r.length>0&&(r.sort(),t.push(...r)),t}),postfixLookupClassGroupIds:(e=>{let t=Object.create(null),r=e.postfixLookupClassGroups;if(r)for(let e=0;e<r.length;e++)t[r[e]]=!0;return t})(n),...(e=>{let t=(e=>{let{theme:t,classGroups:r}=e;return d(r,t)})(e),{conflictingClassGroups:r,conflictingClassGroupModifiers:o}=e;return{getClassGroupId:e=>{if(e.startsWith("[")&&e.endsWith("]")){var r;let t,o,i;return -1===(r=e).slice(1,-1).indexOf(":")?void 0:(o=(t=r.slice(1,-1)).indexOf(":"),(i=t.slice(0,o))?"arbitrary.."+i:void 0)}let o=e.split("-"),i=+(""===o[0]&&o.length>1);return c(o,i,t)},getConflictingClassGroupIds:(e,t)=>{if(t){let t=o[e],i=r[e];if(t){if(i){let e=Array(i.length+t.length);for(let t=0;t<i.length;t++)e[t]=i[t];for(let r=0;r<t.length;r++)e[i.length+r]=t[r];return e}return t}return i||l}return r[e]||l}}})(n)}).cache.get,i=r.cache.set,s=a,a(e)},(...e)=>s(((...e)=>{let t,r,o=0,i="";for(;o<e.length;)(t=e[o++])&&(r=y(t))&&(i&&(i+=" "),i+=r);return i})(...e)));e.s(["f",0,function(...e){return eb(function(){for(var e,t,r=0,o="",i=arguments.length;r<i;r++)(e=arguments[r])&&(t=function e(t){var r,o,i="";if("string"==typeof t||"number"==typeof t)i+=t;else if("object"==typeof t)if(Array.isArray(t)){var s=t.length;for(r=0;r<s;r++)t[r]&&(o=e(t[r]))&&(i&&(i+=" "),i+=o)}else for(o in t)t[o]&&(i&&(i+=" "),i+=o);return i}(e))&&(o&&(o+=" "),o+=t);return o}(e))}],47163)},5014,e=>{"use strict";var t=e.i(71645);let r=(...e)=>{let t=new Set;for(let r of e)if("string"==typeof r)for(let e of r.split(/\s+/))e&&t.add(e);return[...t].join(" ")},o={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"},i=(0,t.createContext)({}),s=(0,t.forwardRef)(({color:e,size:s,width:a,height:n,strokeWidth:l,absoluteStrokeWidth:c,nonScalingStroke:d,className:u="",children:h,iconNode:p=[],icon:m={node:p,aliases:[],size:24},...f},g)=>{let{size:b=24,strokeWidth:x=2,absoluteStrokeWidth:v=!1,nonScalingStroke:w=!1,color:y="currentColor",className:_=""}=(0,t.useContext)(i)??{},k=!!h||(e=>{if(null==e||"object"!=typeof e)return!1;for(let t in e)if(Object.prototype.hasOwnProperty.call(e,t)&&(t.startsWith("aria-")||"role"===t||"title"===t)&&null!=e[t])return!0;return!1})(f),[z,S,R=[]]=function(e,t={}){return function(e,t={}){let i=t.attributeNames??{},s=e=>i[e]??e,a=e.size??e.width??o.width,n=e.size??e.height??o.height,l=e.aliases?.filter(e=>"string"==typeof e&&""!==e.trim()).map(e=>`lucide-${e}`)??[],c=[...e.name?[`lucide-${e.name}`]:[],...l],d=t.className?.split(" ").filter(Boolean)??[],u=!1===t.includeDefaultClasses?r(...d):r("lucide",...c,...d),h=t.absoluteStrokeWidth?Number(t.strokeWidth??o["stroke-width"])*Number(e.size??e.width??o.width)/Number(t.size??t.width??o.width):t.strokeWidth??o["stroke-width"];return["svg",{...Object.entries(o).reduce((e,[t,r])=>(e[s(t)]=r,e),{}),..."color"in t&&t.color&&{[s("stroke")]:t.color},..."size"in t&&null!=t.size&&{[s("width")]:t.size,[s("height")]:t.size},..."width"in t&&null!=t.width&&{[s("width")]:t.width},..."height"in t&&null!=t.height&&{[s("height")]:t.height},[s("stroke-width")]:h,...u&&{[s("class")]:u},[s("viewBox")]:`0 0 ${a} ${n}`,...!1===t.hasA11yProp?{[s("aria-hidden")]:"true"}:{},..."attributes"in t&&t.attributes},e.node.map(e=>{let[r,o,i]=e,a=t.nonScalingStroke?{[s("vector-effect")]:"non-scaling-stroke",...o}:o;return i?[r,a,i]:[r,a]})]}(e,{...t,attributeNames:{...t.attributeNames,class:"className","stroke-width":"strokeWidth","stroke-linecap":"strokeLinecap","stroke-linejoin":"strokeLinejoin","vector-effect":"vectorEffect"}})}(m,{color:e??y,width:a??s??b,height:n??s??b,strokeWidth:l??x,absoluteStrokeWidth:c??v,nonScalingStroke:d??w,className:r(_,u),hasA11yProp:k,attributes:f});return(0,t.createElement)(z,{ref:g,...S},[...R.map(([e,r])=>(0,t.createElement)(e,r)),...Array.isArray(h)?h:[h]])});e.s(["default",0,s],5014)},56420,e=>{"use strict";var t=e.i(71645),r=e.i(5014);e.s(["f",0,function(e,o=[],i=[]){let s,a="string"==typeof e?function(e,t,r=[]){if(null==t)throw Error("[lucide]: iconNode is required when icon name is used");return{name:(e.match(/\d+[xX]\d+|[A-Z]?[a-z]+|[A-Z]|\d+/g)??[]).join("-").toLowerCase(),size:24,node:t,...r.length>0?{aliases:r}:{}}}(e,o,i):e,n=(0,t.forwardRef)(({className:e,...o},i)=>(0,t.createElement)(r.default,{ref:i,icon:a,className:e,...o}));return a.name&&(n.displayName=(s=(e=>{let t="",r=!1;for(let o of e){if("-"===o||"_"===o||o<=" "){r=t.length>0;continue}0===t.length?t+=o.toLowerCase():t+=r?o.toUpperCase():o,r=!1}return t})(a.name)).charAt(0).toUpperCase()+s.slice(1)),n}],56420)},75387,45157,e=>{"use strict";var t=e.i(56420);let r={name:"phone",size:24,node:[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]]};r.node;let o=(0,t.f)(r);e.s(["f",0,o],75387);var i=e.i(43476);e.s(["O",0,function(e){return(0,i.jsx)("svg",{viewBox:"0 0 24 24","aria-hidden":"true",...e,children:(0,i.jsx)("path",{d:"M12 1.5l2.6 7.9H23l-6.8 4.9 2.6 7.9L12 17.3l-6.8 4.9 2.6-7.9L1 9.4h8.4z"})})},"B",0,function(e){return(0,i.jsx)("svg",{viewBox:"0 0 24 24","aria-hidden":"true",...e,children:(0,i.jsx)("path",{d:"M17.5 14.4c-.3-.1-1.8-.9-2-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.2-.2.2-.3.2-.6.1-.3-.1-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.4-.5.3-.5c.1-.2 0-.4 0-.5l-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.2 5.1 4.5 2.5 1 3 .8 3.6.8.6-.1 1.8-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.2-.3-.3-.6-.4zM12 21.8c-1.8 0-3.5-.5-5-1.4l-.4-.2-3.7 1 1-3.6-.2-.4A9.8 9.8 0 1112 21.8zM12 0a12 12 0 00-10.3 18.1L0 24l6.1-1.6A12 12 0 1012 0z"})})}],45157)}]);